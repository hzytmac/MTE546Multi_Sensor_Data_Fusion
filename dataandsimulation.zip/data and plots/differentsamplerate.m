clear all;
clc;

import1=load('S4_4cm_2.mat');
data1=import1.data;
import2=load('S4_4cm_2_800hz.mat');
data2=import2.data;
time1=import1.time;
time2=import2.time;

figure
plot(time1,data1,'r');
hold on;
plot(time2,data2,'b');
title('Voltage vs Time');
xlabel('time');
ylabel('distance');
legend('Sample Rate=8000','Sample Rate=800');