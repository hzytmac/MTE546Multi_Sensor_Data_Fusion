clear all;
clc;

syms x
f(x) = -2.362e-04*x^3+0.0155*x^2-0.3459*x+3.0776;
g = finverse(f);
m(x) = -1.36e-05*x^3+0.0024*x^2-0.1443*x+3.33;
n = finverse(m);
p(x) = -2.11e-06*x^3+7.14e-04*x^2-0.0825*x+3.83;
q = finverse(p);

