close all;
clc;

import1=load('S10_30cm_2.mat');
data1=import1.data;
import2=load('S10_30cm_2_paintedsteel.mat');
data2=import2.data;
import3=load('S10_30cm_2_30deg.mat');
data3=import3.data;
time1=import1.time;

figure
plot(time1,data1,'r');
hold on;
plot(time1,data2,'b');
hold on;
plot(time1,data3,'g');
title('Voltage vs Time');
xlabel('time');
ylabel('voltage');
legend('Normal','Steel','30 degree');