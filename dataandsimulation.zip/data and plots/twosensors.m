clear all;
clc;

%% import everything/measurement data
import1=load('discompare_10cm_S4_S10_2.mat');
volts1=import1.data(:,1);
voltm1=import1.data(:,2);
distm1=transpose(linspace(10,10,4000));
import2=load('discompare_20cm_S4_S10_2.mat');
volts2=import2.data(:,1);
voltm2=import2.data(:,2);
distm2=transpose(linspace(20,20,4000));
import3=load('discompare_30cm_S4_S10_2.mat');
volts3=import3.data(:,1);
voltm3=import3.data(:,2);
distm3=transpose(linspace(30,30,4000));
time=import1.time;

%% g=f(voltage)
syms x
f(x) = -2.362e-04*x^3+0.0155*x^2-0.3459*x+3.0776;
g = finverse(f);
m(x) = -1.36e-05*x^3+0.0024*x^2-0.1443*x+3.33;
n = finverse(m);

%% distance calculation
distanceS1=double(g(volts1));
distanceS2=double(g(volts2));
distanceS3=double(g(volts3));
distanceM1=double(n(voltm1));
distanceM2=double(n(voltm2));
distanceM3=double(n(voltm3));
distanceAVG1=(distanceS1+distanceM1)/2;
distanceAVG2=(distanceS2+distanceM2)/2;
distanceAVG3=(distanceS3+distanceM3)/2;

%% plots
figure
plot(time,distanceS1,'r');
hold on;
plot(time,distanceM1,'b');
hold on;
plot(time,distanceAVG1,'g');
hold on;
title('Distance vs Time at 10cm');
xlabel('time');
ylabel('distance');
legend('short range IR','medium range IR','average of sensor mesurement');

figure
plot(time,distanceS2,'r');
hold on;
plot(time,distanceM2,'b');
hold on;
plot(time,distanceAVG2,'g');
hold on;
title('Distance vs Time at 20cm');
xlabel('time');
ylabel('distance');
legend('short range IR','medium range IR','average of sensor mesurement');

figure
plot(time,distanceS3,'r');
hold on;
plot(time,distanceM3,'b');
hold on;
plot(time,distanceAVG3,'g');
hold on;
title('Distance vs Time at 30cm');
xlabel('time');
ylabel('distance');
legend('short range IR','medium range IR','average of sensor mesurement');
