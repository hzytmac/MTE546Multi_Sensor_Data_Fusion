clear all;
clc;
%% import everything
import1=load('S4_4cm_2.mat');
data1=import1.data;
import2=load('S4_10cm_2.mat');
data2=import2.data;
import3=load('S4_15cm_2.mat');
data3=import3.data;
import4=load('S4_20cm_2.mat');
data4=import4.data;
import5=load('S4_25cm_2.mat');
data5=import5.data;
import6=load('S4_30cm_2.mat');
data6=import6.data;
data=[data1;data2;data3;data4;data5;data6];

%% avg
mean1=mean(data1);
mean2=mean(data2);
mean3=mean(data3);
mean4=mean(data4);
mean5=mean(data5);
mean6=mean(data6);
meanV=[mean1;mean2;mean3;mean4;mean5;mean6];
dist=[4;10;15;20;25;30];
%% line fitting
coeffs = polyfit(dist,meanV,3);
% Get fitted values
fittedX = linspace(min(dist), max(dist));
fittedY = polyval(coeffs, fittedX);

%% max voltage difference
maxVD=max(abs(meanV-(-2.362e-04*power(dist,3)+0.0155*power(dist,2)-0.3459*dist+3.0776)));
%% 1st sensor modeling with line fitting
figure
plot(dist,meanV,'color','b');
hold on;
plot(fittedX,fittedY,'color','r');
title('Distance vs Output Voltage');
xlabel('distance');
ylabel('Output Voltage');
legend('raw','fitted');

%% normal distribution characteristic
pd1=fitdist(data1,'normal');
pd2=fitdist(data2,'normal');
pd3=fitdist(data3,'normal');
pd4=fitdist(data4,'normal');
pd5=fitdist(data5,'normal');
pd6=fitdist(data6,'normal');

%% goodness of fit
h1=chi2gof(data1);
%% fit normal distribution
figure
subplot(2,3,1)
histogram(data1);
hold on;
histfit(data1);
hold on;
subplot(2,3,2)
histogram(data2);
hold on;
histfit(data2);
hold on;
subplot(2,3,3)
histogram(data3);
hold on;
histfit(data3);
hold on;
subplot(2,3,4)
histogram(data4);
hold on;
histfit(data4);
hold on;
subplot(2,3,5)
histogram(data5);
hold on;
histfit(data5);
hold on;
subplot(2,3,6)
histogram(data6);
hold on;
histfit(data6);
hold on;
