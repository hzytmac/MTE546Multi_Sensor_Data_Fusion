clear all;
clc;

%% import everything
import1=load('S10_10cm_2.mat');
data1=import1.data;
import2=load('S10_20cm_2.mat');
data2=import2.data;
import3=load('S10_30cm_2.mat');
data3=import3.data;
import4=load('S10_40cm_2.mat');
data4=import4.data;
import5=load('S10_50cm_2.mat');
data5=import5.data;
import6=load('S10_60cm_2.mat');
data6=import6.data;
import7=load('S10_70cm_2.mat');
data7=import7.data;
import8=load('S10_80cm_2.mat');
data8=import8.data;
data=[data1;data2;data3;data4;data5;data6;data7;data8];
maxVD=abs(max(data1)-(-0.0215*10+1.7795)); %max voltage difference
%% avg
mean1=mean(data1);
mean2=mean(data2);
mean3=mean(data3);
mean4=mean(data4);
mean5=mean(data5);
mean6=mean(data6);
mean7=mean(data7);
mean8=mean(data8);
meanV=[mean1;mean2;mean3;mean4;mean5;mean6;mean7;mean8];
dist=[10;20;30;40;50;60;70;80];
%% line fitting
coeffs = polyfit(dist,meanV, 3);
% Get fitted values
fittedX = linspace(min(dist), max(dist));
fittedY = polyval(coeffs, fittedX);

%% max voltage difference
maxVD=max(abs(meanV-(-1.36e-05*power(dist,3)+0.0024*power(dist,2)-0.1443*dist+3.33)));

%% 1st sensor modeling with line fitting
figure
plot(dist,meanV,'color','b');
hold on;
plot(fittedX,fittedY,'color','r');
title('Distance vs Output Voltage');
xlabel('distance');
ylabel('Output Voltage');
legend('raw','fitted');


%% normal distribution characteristic
pd1=fitdist(data1,'normal');
pd2=fitdist(data2,'normal');
pd3=fitdist(data3,'normal');
pd4=fitdist(data4,'normal');
pd5=fitdist(data5,'normal');
pd6=fitdist(data6,'normal');
pd7=fitdist(data7,'normal');
pd8=fitdist(data8,'normal');
%% fit normal distribution

figure
subplot(2,4,1)
histogram(data1);
hold on;
histfit(data1);
hold on;
subplot(2,4,2)
histogram(data2);
hold on;
histfit(data2);
hold on;
subplot(2,4,3)
histogram(data3);
hold on;
histfit(data3);
hold on;
subplot(2,4,4)
histogram(data4);
hold on;
histfit(data4);
hold on;
subplot(2,4,5)
histogram(data5);
hold on;
histfit(data5);
hold on;
subplot(2,4,6)
histogram(data6);
hold on;
histfit(data6);
hold on;
subplot(2,4,7)
histogram(data7);
hold on;
histfit(data7);
hold on;
subplot(2,4,8)
histogram(data8);
hold on;
histfit(data8);
hold on;